﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_B
{
    public class Course : IRegister
    {
        public string courseID { get; set; }
        public string courseNm { get; set; }
        public double cost { get; set; }
        public int semHrs { get; set; }

        public Course(string num, string name, double rate, int hours)
        {
            courseID = num;
            courseNm = name;
            cost = rate;
            semHrs = hours;
        }

        public int TotalHrs//property
        {
            get
            {
                return semHrs;
            }
        }

        public string Save
        {
            get
            {
                return "\n\n" + courseID + ": " + courseNm + "\n" + "Cost: " +
                    cost.ToString("c") + ", " + semHrs.ToString() + "  semester hours";                   
            }
        }

        public void Print()
        {
            Console.WriteLine(Save);
        }
    }
}
