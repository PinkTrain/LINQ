﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_B
{
    class Program
    {
        static void Main(string[] args)
        {
            Course c1 = new Course("COP2301", "Data Structures", 198.00, 2);
            Course c2 = new Course("EEL3875", "Database Systems", 278.00, 3);
            Course c3 = new Course("CEN6084", "Advanced Programming", 350.00, 4);

            c1.Print();
            c2.Print();

            Student may = new Graduate(1232, "Web111");
            Student tim = new Graduate(1534, "ADN104");
            Student david = new Graduate(2221, "PAN234");

            may.AddCourse(c1);
            may.Print();

            tim.AddCourse(c2);
            tim.AddCourse(c1);
            tim.AddCourse(c3);
            tim.Print();
            
            david.Print();

            Console.ReadLine();
        }
    }
}
