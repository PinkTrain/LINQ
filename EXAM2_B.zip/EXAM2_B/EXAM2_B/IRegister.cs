﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_B
{
    interface IRegister
    {
        string Save{get;}
        void Print();
    }
}
