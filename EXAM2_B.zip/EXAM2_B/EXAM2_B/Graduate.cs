﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_B
{
    sealed class Graduate : Student
    {
        //Inherits Student class
        public Graduate(int stuID, string loc) : base(stuID, loc)
        {

        }

        protected override int TotalSemHours()
        {
            var totalSemHours = 0;
            foreach (var course in stuCourse)
            {
                totalSemHours += course.TotalHrs;
            }
            return totalSemHours;
        }
    }
}
