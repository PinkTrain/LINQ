﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_B
{   
    abstract class Student : IRegister
    {
        protected int studentId;
        protected string section;
        protected List<Course> stuCourse;

        public Student(int stuID, string loc)
        {
            studentId = stuID;
            section = loc;
            stuCourse = new List<Course>(); 
        }

        protected Student()
        {
        }

        public string Save
        {
            get
            {
                var value = studentId.ToString() + " " + section;
                if (stuCourse.Count == 0)
                {
                    value += "\n\n" + "No class registered.";
                }
                else
                {
                    foreach (Course c in stuCourse)
                    {
                        value += c.Save;
                    }
                }
                return value;
            }
        }

        public void AddCourse(Course n)
        {
            stuCourse.Add(n);
        }

        public void Print()
        {
            Console.WriteLine(Save);
            Console.WriteLine(GetRegisteredCourses());
        }

        //Lists Hours of Registered Courses
        string GetRegisteredCourses()
        {
            string registeredCourse = "";
            registeredCourse = "Total Semester Hours Registered: " 
                                    + TotalSemHours().ToString(); 
            return registeredCourse;
        }

        //total semester hours with no parameters
        protected abstract int TotalSemHours();
    }
}
